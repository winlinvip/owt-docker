cd init
npm install
./init.sh IP/URL --dbowt=IPurl/owtdb

