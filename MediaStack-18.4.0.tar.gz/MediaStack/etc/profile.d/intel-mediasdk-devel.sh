# add a required environment setting for development of intel mediasdk
# apps or building the intel mediasdk samples
export MFX_HOME=/opt/intel/mediasdk
